# ADDENDUM TO FINANCIAL AFFIDAVIT
**(Clarifications on Non-Marital Status of ARIBIA LLC, Lack of Petitioner's Contributions, and Respondent's Personal Disclosures)**

**In the Circuit Court of Cook County, Illinois**  
**County Department, Domestic Relations Division**

**In re the Marriage of:**
**LUISA FERNANDA ARIAS MONTEALEGRE,** *Petitioner,* **v.** **NICHOLAS ANTHONY BIANCHI,** *Respondent*

**Case No.: 2024D007847**

---

I, Nicholas Anthony Bianchi, being first duly sworn on oath, submit this Addendum to my Financial Affidavit to:

1. **Establish that ARIBIA LLC (and all related properties) are non-marital.**
2. **Refute Petitioner's accusations of mismanagement, harassment, and attempts to conceal assets.**
3. **Document Petitioner's minimal cohabitation, unsubstantial engagement, misuse of funds, short-notice TRO filing, and disparaging treatment regarding my mental health conditions (CPTSD and ADHD).**

## I. PRE-MARITAL ORIGINS & LIMITED MARITAL COHABITATION

### ARIBIA LLC Formation & Funding (Pre-Marriage)

ARIBIA LLC was established on **July 15, 2022**, well before our December 30, 2022 marriage. *(See Exhibit A: 2022 07 15 Articles of Organization).*

All initial capital contributions (approximately **$122,500**) were drawn from my pre-marital Fidelity accounts and EEOC settlement.

**No joint funds were ever used to purchase or maintain these assets.**

[Document continues with all sections from original addendum...]

*This file was truncated for space. Full document available at checkpoint restoration.*
