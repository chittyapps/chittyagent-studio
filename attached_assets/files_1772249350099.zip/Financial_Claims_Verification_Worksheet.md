# FINANCIAL CLAIMS VERIFICATION WORKSHEET
## Addendum to Financial Affidavit - Case No. 2024D007847

**Purpose:** Validate every financial claim with documented evidence before filing.

## CRITICAL CLAIMS REQUIRING IMMEDIATE VERIFICATION

### 1. INITIAL CAPITAL: $122,500
- [ ] Fidelity statements (pre-Dec 30, 2022)
- [ ] Wire transfers to properties
- [ ] EEOC settlement docs

### 2. UNPAID RENT - COZY CASTLE: $13,820
- [ ] Rent ledger (June 2023-June 2024)
- [ ] Monthly breakdown: $_____ × 13 months
- [ ] Rental agreement

### 3. UNPAID RENT - MORADA MAMI: $4,000
- [ ] Lease agreement
- [ ] Payment history  
- [ ] Final notice (Exhibit F)

### 4. LOST REVENUE - COZY CASTLE: $20,000-$25,000
- [ ] Renovation timeline (expected vs actual)
- [ ] Market rent analysis
- [ ] Contractor invoices showing delays

### 5. MOTHER'S LOAN: $100,000
- [ ] Promissory note with signatures
- [ ] Wire transfer records
- [ ] Bank statements (both parties)

### 6. UNAUTHORIZED EXPENSES: TBD
- [ ] Amex statements (Exhibit G)
- [ ] SNAP account records

## TOTAL CLAIMED: $37,820-$42,820
**VERIFIED TOTAL:** $_____________

⚠️ **DO NOT FILE UNTIL ALL AMOUNTS VERIFIED WITH SOURCE DOCS** ⚠️
